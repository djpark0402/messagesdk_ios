//
//  OpenDID_DataModel.h
//  OpenDID_DataModel
//
//  Created by 박주현 on 6/14/24.
//

#import <Foundation/Foundation.h>

//! Project version number for OpenDID_DataModel.
FOUNDATION_EXPORT double OpenDID_DataModelVersionNumber;

//! Project version string for OpenDID_DataModel.
FOUNDATION_EXPORT const unsigned char OpenDID_DataModelVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OpenDID_DataModel/PublicHeader.h>


